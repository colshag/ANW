/*
 Slots - part 2
 */

#include "py_slot.h"


void class_Slots2()
{
  SLOT("Vec3Slot",vec3d);
  SLOT("Vec4Slot",vec4d);
  SLOT("StrSlot",string);
}
