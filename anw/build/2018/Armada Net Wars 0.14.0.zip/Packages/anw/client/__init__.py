# ---------------------------------------------------------------------------
# Armada Net Wars (ANW)
# client package
# Written by Chris Lewis
# ---------------------------------------------------------------------------
# This contains all the main client classes dealing with running the client app
# it has been placed in a package to allow code sharing for test running and
# running the client
# ---------------------------------------------------------------------------
