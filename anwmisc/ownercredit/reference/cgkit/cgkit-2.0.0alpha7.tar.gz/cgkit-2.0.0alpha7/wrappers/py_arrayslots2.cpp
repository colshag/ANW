/*
 ArraySlots - part 2
 */

#include "py_slot.h"

void class_ArraySlots2()
{
  ARRAYSLOT("Vec3ArraySlot",vec3d);
  ARRAYSLOT("Vec4ArraySlot",vec4d);
}
