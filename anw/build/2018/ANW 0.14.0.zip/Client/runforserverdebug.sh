export PYTHONPATH=$PYTHONPATH:../Packages/

python run.py ANW4