# ---------------------------------------------------------------------------
# Armada Net Wars (ANW)
# war package
# Written by Chris Lewis
# ---------------------------------------------------------------------------
# This is the war package shared between client and server, used for war simulation
# ---------------------------------------------------------------------------
