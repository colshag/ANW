import os
       
##for key in ['Q','W','E','R','T','Y','U','I','O']:
       ##name = 'main_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
     
##for key in ['A','S','D','Z','X','C']:
       ##name = 'scroll_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C']:
       ##name = 'age_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C']:
       ##name = 'city_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
       
##for key in ['af','cm','ss','rc','sc','dc','rs','js','mf','fa','ma','sy','mi','wg']:
       ##name = 'industry_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['1','2','3','4','5','6']:
       ##name = 'system_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['onetime','tradegen','cancel']:
       ##name = 'trade_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C','G','F','V']:
       ##name = 'trade_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['cancel', 'removedesign', 'submitdesign', 'simulatedesign', 'alltech','mytech','setupsim']:
       ##name = 'design_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','V','Z','X','C','1','2','3','4']:
       ##name = 'design_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','F','G','Z','X','C','V','B']:
       ##name = 'mapmove_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['buildships', 'repairships', 'upgradeships']:
       ##name = 'shipyard_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

for key in ['warparmies', 'warpships', 'cancel', 'selectall','selectdamaged']:
       name = 'mapmove_' + key
       os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['simulatedesign']:
       ##name = 'bv_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C','F','V']:
       ##name = 'bv_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['buildmarines', 'refitmarines', 'upgrademarines']:
       ##name = 'mi_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
       
##for key in ['leveragemax']:
       ##name = 'leverage_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C','G','F','V']:
       ##name = 'leverage_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['swap', 'sort']:
       ##name = 'map_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
       ##for key in ['buildmarines', 'refitmarines', 'upgrademarines']:
       ##name = 'mi_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['submit','cancel','selectall']:
       ##name = 'order_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['sendmail','increase','decrease']:
       ##name = 'diplomacy_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C']:
       ##name = 'movearmies_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
       
##for key in ['A','S','D','Z','X','C']:
       ##name = 'movearmada_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
       
##for key in ['A','S','D','F','G','Z','X','C','V']:
       ##name = 'sys_sell_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['buyal','buyec','buyia','sellal','sellec','sellia','selectall']:
       ##name = 'market_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','F','G','Z','X','C','V']:
       ##name = 'sys_buy_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X','C','V']:
       ##name = 'sendcredit_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['A','S','D','Z','X']:
       ##name = 'multisim_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 96,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['blankyes','blankno','cancel']:
       ##name = 'questionendround_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))

##for key in ['blankyes','blankno']:
       ##name = 'questionsurrender_' + key
       ##os.popen4('egg-texture-cards -o %s_maps.egg -p 800,100 %s_ready.png %s_click.png %s_rollover.png %s_disabled.png' % (name, name, name, name, name))
 